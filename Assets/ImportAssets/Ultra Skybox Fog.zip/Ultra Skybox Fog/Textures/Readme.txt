Skyboxes are CC0, taken from: https://hdrihaven.com/
Please check them out for more AMAZING skyboxes.
Support him on patreon: https://www.patreon.com/hdrihaven